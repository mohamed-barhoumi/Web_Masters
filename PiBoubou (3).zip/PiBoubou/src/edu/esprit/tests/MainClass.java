/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.esprit.tests;

import edu.esprit.entities.Coach;
import edu.esprit.entities.Evenement;
import edu.esprit.services.CoachCrud;
import edu.esprit.services.EvenementCrud;
import edu.esprit.utils.DataSource;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.sql.Date;



/**
 *
 * @author a
 */
public class MainClass {
  
    public static void main (String[] args) throws SQLException{
        
        
        SimpleDateFormat simpleDateFormat= new SimpleDateFormat("dd/MM/yyyy");
        //MyConnection mc= new MyConnection();
        
        EvenementCrud evt = new EvenementCrud();
        CoachCrud c =new CoachCrud();
        Coach c1 = new Coach("linda","ammar","photo",2563);
        c.ajouterEvent(c1);
        //c.supprimerEvent(1);
       //Evenement e= new Evenement (50,20,"course","fdjkfdjk","image",15.2,new Date(),new Date());
       //Evenement e=new Evenement("perla","poupou","pipi",14,"gfgf","jfk",50,42);
        //evt.ajouterEvent(e);
        
        System.out.println(evt.afficherEvents());
        //evt.supprimerEvent(2);
         System.out.println(evt.afficherEvents());
         System.out.println(c.afficher());
        
        
       
    }
   
}
