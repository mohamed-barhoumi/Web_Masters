/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.esprit.gui;

import edu.esprit.entities.Evenement;
import edu.esprit.services.EvenementCrud;
import javafx.scene.image.Image;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javafx.scene.image.ImageView;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Date;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import static java.util.Collections.list;
import static java.util.Collections.sort;
import static java.util.Locale.filter;

import javafx.collections.transformation.FilteredList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author a
 */
public class EvenementController implements Initializable {

    @FXML
    private TextField cherch;
    @FXML
    private Button actualiser;
    @FXML
    private TableView<Evenement> tableid;
    @FXML
    private TableColumn<Evenement, Integer> colId;
    @FXML
    private TableColumn<Evenement, String> colTitre;
    @FXML
    private TableColumn<Evenement, String> colImage;
    @FXML
    private TableColumn<Evenement, String> colDescription;
    @FXML
    private TableColumn<Evenement, Double> colPrix;
    @FXML
    private TableColumn<Evenement, Date> colDateDeb;
    @FXML
    private TableColumn<Evenement, Date> colDatefin;
   

    @FXML
    private Button ajout;
    @FXML
    private DatePicker idDateFin;
    @FXML
    private DatePicker idDatedeb;
    @FXML
    private TextField idTitre;
    @FXML
    private TextField idImage;
    @FXML
    private TextField idDescription;
    @FXML
    private TextField idPrix;
    @FXML
    private TextField idPlace;
    @FXML
    private TextField idInscrit;
    @FXML
    private Button idParc;
     ObservableList list = FXCollections.observableArrayList();
       FilteredList<Evenement> filter = new FilteredList<>(list, e -> true);
    SortedList<Evenement> sort = new SortedList<>(filter);
     int id;
     

    /**
     * Initializes the controller class.
     */
          EvenementCrud evt = new EvenementCrud();
    @FXML
    private TableColumn<?, ?> colAddPromo;
    @FXML
    private Button btnSupprimer;
    @FXML
    private Button btnModifier;
    @FXML
    private TableColumn<?, ?> colPlace;
    @FXML
    private TableColumn<?, ?> colInscrit;
      public void loadDataEvenement(){
    //        ObservableListrTournoi> list=  loarTournoi();
 
          list.clear();
          list.addAll(evt.afficherEvents());

         colId.setCellValueFactory(new PropertyValueFactory<>("id"));
         colTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));
         colImage.setCellValueFactory(new PropertyValueFactory<>("image"));
          colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));


        
             colPrix.setCellValueFactory(new PropertyValueFactory<>("prix"));

        colDateDeb.setCellValueFactory(new PropertyValueFactory<>("date_debut"));
        colDatefin.setCellValueFactory(new PropertyValueFactory<>("date_fin"));
        colPlace.setCellValueFactory(new PropertyValueFactory<>("nbplace"));
        colInscrit.setCellValueFactory(new PropertyValueFactory<>("nbinscrit"));

         tableid.setItems(list);
          btnSupprimer.setDisable(true);
     btnModifier.setDisable(true);
 
    }
      
      
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
      loadDataEvenement();
     
       tableid.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue)
                -> {

                    if(newValue!=null){
                          System.out.println(newValue);

                          id=((Evenement) newValue).getId();
                      populateInputs((Evenement) newValue);
               }

        });
        // TODO
    }  
    
    
    public void  populateInputs(Evenement Evenement){
        //Double prix=Double.parseDouble(idPrix.getText());
         //Integer place=Integer.parseInteger(idPlace.getText());
        //String tot = Double.toString(prix);

          idTitre.setText(Evenement.getTitre());




         idImage.setText(Evenement.getImage());
 
         idDescription.setText(Evenement.getDescription());
          idPrix.setText(""+Evenement.getPrix());
           
              idDatedeb.setValue(Evenement.getDate_debut().toLocalDate());
            idDateFin.setValue(Evenement.getDate_fin().toLocalDate());
             idPlace.setText(""+Evenement.getNbplace());
              idInscrit.setText(""+Evenement.getNbinscrit());


           btnModifier.setDisable(false);
        btnSupprimer.setDisable(false);





   }
    
    
 @FXML
    private void loadIMG(ActionEvent event) {

        FileChooser fc = new FileChooser();
        File selectedFile = fc.showOpenDialog(null);
        if (selectedFile != null) {

            idImage.setText(selectedFile.getAbsolutePath());
            Image image = new Image(selectedFile.toURI().toString(), 50, 50, true, true);

            System.out.println(selectedFile.getName());
        } else {
            System.out.println("erruer files");
        }
    }
    @FXML
    private void handleMouseAction(MouseEvent event) {
    }
    
     public boolean controleTextFieldCellEdit(CellEditEvent edittedCell) {
        if (!edittedCell.getNewValue().toString().matches(".*[a-zA-Z].*")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Veuillez saisir des lettres");
            alert.showAndWait();
            return true;
        }
        return false;
    }
public boolean validator(){
        String msg="";
       
        if(! idTitre.getText().matches(".*[a-zA-Z].*")){
            msg+=" titre doit etre en lettre, ";
           
        }
        if( idPrix.getText().matches(".*[a-zA-Z].*")){
            msg+=" le prix doit etre numerique";
           
        }
        
          if(idDescription.getText().length()==0){
            msg+=" Champ description vide, ";
           
        }
          
              if(idImage.getText().length()==0){
            msg+=" Champ image vide, \n";
           
        }
                   if(idPlace.getText().length()==0){
            msg+=" Champ contenu vide, \n";
           
        }
              if(idPlace.getText().matches(".*[a-zA-Z].*")){
            msg+=" Nombre des places doit etre numerique, \n";
           
        }
                    if(idInscrit.getText().length()==0){
            msg+=" Champ contenu vide, \n";
           
        }
                                 if(idInscrit.getText().matches(".*[a-zA-Z].*")){
            msg+=" Nombre des inscrits doit etre numerique, \n";
           
        }
                
                 
                 
           if(msg!="")  { 
          
          
          Alert a = new Alert(Alert.AlertType.ERROR,msg, ButtonType.OK);
            a.show();
          return false;
        }   
           return true ;
        
    
    }
    @FXML
    private void ajouter(ActionEvent event) {
        
        if(validator()) {
         EvenementCrud evt = new EvenementCrud();
          Evenement e1 = new Evenement( idTitre.getText(),idDescription.getText(), idImage.getText(), Double.parseDouble(idPrix.getText()),
                    Date.valueOf(idDatedeb.getValue()), Date.valueOf(idDateFin.getValue()), Integer.parseInt(idPlace.getText()), Integer.parseInt(idInscrit.getText()));

        evt.ajouterEvent(e1);
        JOptionPane.showMessageDialog(null, "Evenement ajouté");
          Parent root;
                try {
                    root = FXMLLoader.load(getClass().getResource("Evenemnt.fxml"));
                      ajout.getScene().setRoot(root);
                } catch (IOException ex) {
                    Logger.getLogger(EvenementController.class.getName()).log(Level.SEVERE, null, ex);
                }
           
          
    }}
  

    @FXML
    private void supprimerEvenement(ActionEvent event) {
         evt.supprimerEvent(id);
          JOptionPane.showMessageDialog(null, "Evenement supprimé");
    }

    @FXML
    private void modifierEvenement(ActionEvent event) {
        String titre = colTitre.getText();
        String image = colImage.getText();
        String description = colDescription.getText();
        //Double prix =colPrix.getText();
       // Date datedeb= colDateDeb.getText().toLocalDate();
       // Date datefin= colDatefin.getText().toLocalDate();
       // Integer nbPlace=idPlace.getNbplace();
        //Integer nbinscrit=idPlace.getNbinscrit();
                
 


       // Evenement e = new Evenement(titre, image,description,prix,datedeb,datefin,nbPlace,nbinscrit);


       // evt.modifier(id,e);

    }

    @FXML
    private void refreshTable(MouseEvent event) {
       

           list.clear();
           list.addAll(evt.afficherEvents());

          tableid.setItems(list);

    
    }
    
   
    
    @FXML
    private void recherche() {
        cherch.setOnKeyReleased(e -> {
            cherch.textProperty().addListener((observable, oldValue, newValue) -> {
                filter.setPredicate(Evenement -> {
                    if (newValue == null || newValue.isEmpty()) {
                        return true;
                    }
                    String lowerCaseFilter = newValue.toLowerCase();
                    if (Evenement.getTitre().toLowerCase().contains(lowerCaseFilter)) {
                        return true;
                    } else {
                        return false;
                    }
                });

            });
            sort.comparatorProperty().bind(tableid.comparatorProperty());
            tableid.setItems(sort);
        });
    }
    
}
