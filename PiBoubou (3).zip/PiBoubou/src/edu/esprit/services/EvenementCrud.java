/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.esprit.services;

import edu.esprit.entities.Evenement;
import edu.esprit.utils.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

/**
 *
 * @author a
 */
public class EvenementCrud  implements Iservice<Evenement> {
       Connection cnx = DataSource.getInstance().getCnx();
    
    
    
    @Override
    public void ajouterEvent(Evenement e){
        
         try{
             String req="INSERT INTO evenement (`titre`, `image`, `description`, `prix`, `date_debut`, `date_fin`, `nbplace`, `nbinscrit`)"+"VALUES (?,?,?,?,?,?,?,?)";
        PreparedStatement pst1 = cnx.prepareStatement(req);
            pst1.setString(1,e.getTitre());
            pst1.setString(2,e.getImage());
            pst1.setString(3,e.getDescription());
            pst1.setDouble(4, e.getPrix());
            pst1.setDate(5, e.getDate_debut());
            pst1.setDate(6, e.getDate_fin());
            pst1.setInt(7, e.getNbplace());
            pst1.setInt(8, e.getNbinscrit()); 
            pst1.executeUpdate();
            System.out.println("Evenement Ajoutée");
        }
       
        catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        
       }
    

    
          public List<Evenement>afficherEvents() {
          List <Evenement> myList = new ArrayList<>();
              try{     
              
        
         String req2="SELECT * FROM evenement";
         Statement st=cnx.prepareStatement(req2);
         ResultSet rs=st.executeQuery(req2);
         while (rs.next()){
         Evenement e = new Evenement();
         e.setId(rs.getInt(1));
         e.setTitre(rs.getString("titre"));
         e.setImage(rs.getString("image"));
         e.setTitre(rs.getString("titre"));
       
         e.setDescription(rs.getString("description"));
         e.setPrix(rs.getDouble("prix"));
         e.setDate_debut(rs.getDate("date_debut"));
          e.setDate_fin(rs.getDate("date_fin"));
           e.setNbplace(rs.getInt("nbplace"));
         e.setNbinscrit(rs.getInt("nbinscrit"));
         myList.add(e);
         
         }
              
         } catch(SQLException ex){
    System.err.println(ex.getMessage());
}
return myList;
          }

 
    
      @Override
    public void supprimerEvent(int id) {
        try {
            String req = "DELETE FROM `evenement` WHERE id = " + id;
            Statement st = cnx.createStatement();
            st.executeUpdate(req);
            System.out.println("Evenement supprimé !");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
 
    @Override
    public void modifierEvent(Evenement t) {
       try {
            String req="UPDATE INTO evenement (`titre`, `image`, `description`, `prix`, `date_debut`, `date_fin`, `nbplace`, `nbinscrit`)"+"VALUES (?,?,?,?,?,?,?,?)";
        PreparedStatement pst1 = cnx.prepareStatement(req);
            pst1.setString(1,t.getTitre());
            pst1.setString(2,t.getImage());
            pst1.setString(3,t.getDescription());
            pst1.setDouble(4, t.getPrix());
            pst1.setDate(5, t.getDate_debut());
            pst1.setDate(6, t.getDate_fin());
            pst1.setInt(7, t.getNbplace());
            pst1.setInt(8, t.getNbinscrit()); 
            pst1.executeUpdate();
            System.out.println("Evenement Ajoutée");

            pst1.executeUpdate();
            System.out.println("L'evenement est modifiée avec succés \n ");
        } catch (SQLException ex) {
            System.out.println("Erreur lors de la modification \n " + ex.getMessage());
        }
    }
    
     public void modifier(int id,Evenement t) {
       try {
            String req="UPDATE INTO evenement (`titre`, `image`, `description`, `prix`, `date_debut`, `date_fin`, `nbplace`, `nbinscrit`)"+"VALUES (?,?,?,?,?,?,?,?)";
        PreparedStatement pst1 = cnx.prepareStatement(req);
            pst1.setString(1,t.getTitre());
            pst1.setString(2,t.getImage());
            pst1.setString(3,t.getDescription());
            pst1.setDouble(4, t.getPrix());
            pst1.setDate(5, t.getDate_debut());
            pst1.setDate(6, t.getDate_fin());
            pst1.setInt(7, t.getNbplace());
            pst1.setInt(8, t.getNbinscrit()); 
            pst1.executeUpdate();
            System.out.println("Evenement Ajoutée");

            pst1.executeUpdate();
            System.out.println("L'evenement est modifiée avec succés \n ");
        } catch (SQLException ex) {
            System.out.println("Erreur lors de la modification \n " + ex.getMessage());
        }
    }

        
    
    

   
    public List<Evenement> afficherEvent() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }



}
