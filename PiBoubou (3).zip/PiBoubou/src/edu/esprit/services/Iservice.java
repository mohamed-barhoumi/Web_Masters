/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.esprit.services;
import java.util.List;
/**
 *
 * @author a
 */
public interface Iservice <A>{
      public void ajouterEvent( A t);
  public void supprimerEvent( int t);
  public void modifierEvent( A t);
  public List<A> afficherEvent();
}
